# Importation des bibliothèques nécessaires
import os
import pandas as pd
# Configuration de pandas pour éviter les warnings ('replace' bientôt obsolète)
pd.set_option('future.no_silent_downcasting', True)



# Lecture du fichier CSV
in_path = "./csv/mdb_cleaned.csv.tmp"
x = pd.read_csv(in_path, low_memory=False)

# À savoir :
# Le fichier CSV 'mdb_cleaned.csv' est issu de l'exécution du script 'clean.py' qui s'occupe vérifier la qualité des données et de réaliser les transformations nécessaires.
# Ce fichier est ensuite traité par get_budget_revenue.py pour ajouter les colonnes 'budget' et 'revenue' à partir de données externes (The Movie Database), 
# il devient alors 'mdb_cleaned.csv.tmp'.



if x is not None:
    # Suppression des lignes avec valeur manquante ou 0 dans la colonne 'budget'
    x = x[x['budget'] != '\\N']
    x = x[pd.to_numeric(x['budget'], errors='coerce') > 0]


# Exportation du DataFrame nettoyé vers un nouveau fichier CSV
out_path = "./csv/final_mdb.csv"
if not os.path.exists(out_path):
    x.to_csv(out_path, index=False)
else:
    os.remove(out_path)
    x.to_csv(out_path, index=False)