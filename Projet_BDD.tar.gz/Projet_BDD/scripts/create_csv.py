import pandas as pd

# Lecture des fichier TSV

basics = pd.read_csv("./tsv/title.basics.tsv", sep='\t', dtype={'tconst': str})
ratings = pd.read_csv("./tsv/title.ratings.tsv", sep='\t', dtype={'tconst': str})

x = pd.merge(basics, ratings, on='tconst', how='inner')

# Inverser l'ordre des lignes
x = x.iloc[::-1].reset_index(drop=True)

# Conserver uniquement les lignes où titleType vaut 'movie'
if 'titleType' in x.columns:
    x = x[x['titleType'].isin(['movie', 'tvMovie'])].reset_index(drop=True)

import os

out_path = "./csv/mdb.csv"
if not os.path.exists(out_path):
    x.to_csv(out_path, index=False)
else:
    os.remove(out_path)
    x.to_csv(out_path, index=False)