# Importation des bibliothèques nécessaires
import os
import pandas as pd
# Configuration de pandas pour éviter les warnings ('replace' bientôt obsolète)
pd.set_option('future.no_silent_downcasting', True)



# Lecture du fichier CSV
in_path = "./csv/mdb.csv"
x = pd.read_csv(in_path, low_memory=False)

# À savoir :
# Le fichier CSV 'mdb.csv' est issu de l'aggrégation de plusieurs fichiers TSV distincts provenant de la base : IMDb Developers (voir ci-dessous).
# Fichiers TSV utilisés :
# title.basics.tsv.gz : informations de base sur les titres (films, séries, etc.)
# title.ratings.tsv.gz : notes et votes des titres
# source : https://datasets.imdbws.com/
# Le fichier CSV 'mdb.csv.tmp' est généré par le script 'get_budget.py' qui ajoute la colonne 'budget' en interrogeant l'API TMDb (The Movie Database) à partir des identifiants IMDb.

# Constante définissant le seuil minimum de votes pour qu'un film soit conservé
NO_VOTE_THRESHOLD = 10000



if x is not None:
    # Suppression des colonnes inutiles
    x = x.drop(x.columns[1], axis=1)
    x = x.drop(x.columns[5], axis=1)

    # Renommage des colonnes (si nécessaire)
    x.rename(columns={x.columns[0] : "id_imdb"}, inplace=True)
    x.rename(columns={x.columns[1] : "primary_title"}, inplace=True)
    x.rename(columns={x.columns[2] : "original_title"}, inplace=True)
    x.rename(columns={x.columns[3] : "is_adult"}, inplace=True)
    x.rename(columns={x.columns[4] : "release_year"}, inplace=True)
    x.rename(columns={x.columns[5] : "runtime"}, inplace=True)
    x.rename(columns={x.columns[6] : "genres"}, inplace=True)
    x.rename(columns={x.columns[7] : "average_rating"}, inplace=True)
    x.rename(columns={x.columns[8] : "votes"}, inplace=True)

    # Suppression des lignes avec des valeurs manquantes dans des colonnes spécifiques
    x = x[x['runtime'] != '\\N']
    x = x[x['genres'] != '\\N']

    # Suppression des lignes avec nombre de votes inférieur ou égal à NO_VOTE_THRESHOLD
    x = x[pd.to_numeric(x['votes'], errors='coerce') > NO_VOTE_THRESHOLD]



# Exportation du DataFrame nettoyé vers un nouveau fichier CSV
out_path = "./csv/mdb_cleaned.csv"
if not os.path.exists(out_path):
    x.to_csv(out_path, index=False)
else:
    os.remove(out_path)
    x.to_csv(out_path, index=False)