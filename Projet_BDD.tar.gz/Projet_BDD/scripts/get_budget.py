# Importation des bibliothèques nécessaires
import pandas as pd
import requests, pandas as pd
import signal, sys
import os



# Lecture du fichier CSV
in_path = "./csv/mdb_cleaned.csv"
x = pd.read_csv(in_path, sep=',')



# Fonction de sauvegarde en cas d'interruption
tmp_path = in_path + ".tmp"
def _save_and_exit(*args):
    try:
        i = globals().get("idx", None)
        if i is not None:
            rows_to_save = x.iloc[: i + 1]
        else:
            rows_to_save = x

        file_exists = os.path.exists(tmp_path)
        rows_to_save.to_csv(tmp_path, mode='a' if file_exists else 'w', header=not file_exists, index=False)

        processed_count = start_idx + (i + 1 if i is not None else 0)
        with open("processed.txt", "w") as f:
            f.write(str(processed_count) + "\n")

        print(f"\n\nSaved progress to {tmp_path} (processed {processed_count}).")
    except Exception as e:
        print(f"\nFailed to save progress: {e}")
    sys.exit(1)

# Fonction pour récupérer le budget via l'API TMDb
API_KEY = "b1f9c26048803199fd659857bc820d2a"
def get_tmdb_financials(imdb_id):
    url = f"https://api.themoviedb.org/3/find/{imdb_id}"
    params = {"api_key": API_KEY, "external_source": "imdb_id"}
    r = requests.get(url, params=params).json()
    if r["movie_results"]:
        movie_id = r["movie_results"][0]["id"]
        details = requests.get(f"https://api.themoviedb.org/3/movie/{movie_id}",
                               params={"api_key": API_KEY}).json()
        return details.get("budget")
    return None



# Ajout de la colonne 'budget' si elle n'existe pas déjà
if "budget" not in x.columns:
    x["budget"] = "\\N"
    processed_path = "processed.txt"
    start_idx = 0
    if os.path.exists(processed_path):
        try:
            with open(processed_path, "r") as f:
                content = f.read().strip()
            start_idx = int(content) if content else 0
        except Exception:
            start_idx = 0

# Réinitialisation des index du DataFrame
x.reset_index(drop=True, inplace=True)

# Vérification que l'index de départ n'excède pas le nombre de lignes
if start_idx >= len(x):
    print(f"Start index {start_idx} >= number of rows ({len(x)}). Nothing to do.")
    sys.exit(0)

# Découpage du DataFrame pour reprendre à l'index souhaité
if start_idx:
    x = x.iloc[start_idx:].reset_index(drop=True)

print(f"\nResuming from index {start_idx} (rows to process: {len(x)})")

# Parcours des lignes du DataFrame pour récupérer les budgets
print("")
for idx, row in x.iterrows():
    id_imdb = None
    if "id_imdb" in x.columns and pd.notna(row["id_imdb"]) and str(row["id_imdb"]).strip() != "":
        id_imdb = str(row["id_imdb"]).strip()
    if not id_imdb:
        continue

    try:
        budget = get_tmdb_financials(id_imdb)
    except Exception:
        budget = 0

    x.at[idx, "budget"] = budget if budget is not None else "\\N"

    signal.signal(signal.SIGINT, _save_and_exit)

    print(f"Processed {idx + 1}/{len(x)}: ID IMDb {id_imdb} -> Budget: {budget}", end="\r")