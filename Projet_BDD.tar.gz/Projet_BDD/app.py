import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import plotly.express as px
import plotly.graph_objects as go
import time

# --- 1. Configuration de la page ---
st.set_page_config(page_title="Note Estimator & Analyse", page_icon="🌟", layout="wide")

st.title("🎬 Quel est l'impact des paramètres sur la note d'un film ?")
st.markdown("Cette application utilise un modèle de régression linéaire pour estimer la note moyenne d'un film (sur 10) en fonction de son budget, de sa durée et de ses genres.")

# --- 2. Chargement et Entraînement (Mis en cache pour la rapidité) ---
@st.cache_data(show_spinner="Chargement des données et entraînement du modèle...")
def load_data_and_train_model():
    try:
        # Chargement des données
        df = pd.read_csv('./csv/final_mdb.csv')
        
        # Preprocessing: Encodage des genres
        genres_encoded = df['genres'].str.get_dummies(sep=',')
        
        # Sélection des caractéristiques (Features)
        X = pd.concat([df[['budget', 'runtime']], genres_encoded], axis=1)
        y = df['average_rating']
        
        # Entraînement du modèle
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        model = LinearRegression()
        model.fit(X_train, y_train)
        
        # Calcul du score R² (pour évaluer la performance)
        r2_score = model.score(X_test, y_test)
        
        # Création d'un DataFrame des coefficients pour l'analyse
        coefficients = pd.DataFrame({
            'Feature': X.columns,
            'Coefficient': model.coef_
        })
        
        return model, X.columns.tolist(), df, r2_score, coefficients
    except FileNotFoundError:
        return None, None, None, None, None
    except Exception as e:
        st.error(f"Une erreur inattendue est survenue pendant l'entraînement : {e}")
        return None, None, None, None, None

model, model_columns, df, r2_score, coefficients = load_data_and_train_model()

if model is None:
    st.error("Erreur critique : Le fichier './csv/final_mdb.csv' est introuvable ou les données sont invalides.")
    st.stop()

# Séparation des genres des autres caractéristiques
available_genres = [col for col in model_columns if col not in ['budget', 'runtime']]


# ====================================================================
# --- PARTIE 1 : INTERFACE DE PRÉDICTION ---
# ====================================================================

st.header("⚙️ Outil d'Estimation de Note")

# Colonnes pour la mise en page
col1, col2, col3 = st.columns([1, 1, 1])

with col1:
    budget = st.number_input("Budget ($)", min_value=0, value=50000000, step=100000, help="Le budget de production du film.")

with col2:
    runtime = st.number_input("Durée (minutes)", min_value=1, value=110, step=1, help="La durée du film en minutes.")

with col3:
    selected_genres = st.multiselect("Sélectionnez les genres", available_genres, default=['Drama', 'Action'], help="Choisissez un ou plusieurs genres pour le film.")

# Bouton de prédiction
if st.button("🚀 Prédire la note", use_container_width=True):
    with st.spinner('Calcul de la note...'):
        time.sleep(0.5) # Petite pause pour l'effet
        
        # Création d'un DataFrame vide avec les mêmes colonnes que le modèle
        input_data = pd.DataFrame(0, index=[0], columns=model_columns)
        
        # Remplissage des valeurs continues
        input_data['budget'] = budget
        input_data['runtime'] = runtime
        
        # Mise à 1 pour les genres sélectionnés
        for genre in selected_genres:
            if genre in input_data.columns:
                input_data[genre] = 1
                
        # Prédiction (attention à la mise à l'échelle si elle avait été appliquée, ici elle ne l'est pas)
        try:
            prediction = model.predict(input_data)[0]
            
            # Affichage du résultat avec un style
            st.metric(label="Note Moyenne Prédite", value=f"{prediction:.2f} / 10", delta=f"R² du modèle: {r2_score:.3f}")
            st.balloons()

        except ValueError:
             st.error("Erreur de prédiction. Veuillez vérifier les entrées.")


# ====================================================================
# --- PARTIE 2 : ANALYSE ET GRAPHIQUES ---
# ====================================================================

st.markdown("---")
st.header("📊 Analyses des Données et du Modèle")
st.write("Explorez les relations entre les caractéristiques des films et leur note moyenne dans le jeu de données.")

tab_eda, tab_model = st.tabs(["Analyse Exploratoire des Données (EDA)", "Interprétation du Modèle (Coefficients)"])

# --- TAB 1: Analyse Exploratoire des Données (EDA) ---
with tab_eda:
    
    st.subheader("Distribution des Notes Moyennes")
    fig_hist_rating = px.histogram(df, x='average_rating', 
                                   nbins=30, 
                                   title='Distribution des Notes Moyennes',
                                   labels={'average_rating': 'Note Moyenne (/10)'})
    fig_hist_rating.update_traces(marker_color='#FF5733', opacity=0.8)
    st.plotly_chart(fig_hist_rating, use_container_width=True)
    st.info(f"Le jeu de données contient {len(df)} films. La note moyenne globale est de **{df['average_rating'].mean():.2f}**.")
    
    st.subheader("Relations entre les Variables et la Note")
    
    # Nuage de points Budget vs Rating
    col_a, col_b = st.columns(2)
    with col_a:
        st.write("##### Budget vs Note")
        # Utilisation de la log-échelle pour rendre les budgets plus visibles
        df_plot = df[df['budget'] > 0].copy()
        df_plot['log_budget'] = np.log10(df_plot['budget'])
        
        fig_budget = px.scatter(df_plot, x='log_budget', y='average_rating',
                                hover_data=['primary_title', 'budget'],
                                title='Note en fonction du Budget (Échelle Log)',
                                labels={'log_budget': 'Log10(Budget en $)', 'average_rating': 'Note Moyenne'},
                                color_continuous_scale=px.colors.sequential.Sunset)
        st.plotly_chart(fig_budget, use_container_width=True)

    # Nuage de points Runtime vs Rating
    with col_b:
        st.write("##### Durée vs Note")
        fig_runtime = px.scatter(df, x='runtime', y='average_rating',
                                hover_data=['primary_title', 'runtime'],
                                title='Note en fonction de la Durée',
                                labels={'runtime': 'Durée (minutes)', 'average_rating': 'Note Moyenne'})
        fig_runtime.update_traces(marker=dict(color='#33FF57', opacity=0.6))
        st.plotly_chart(fig_runtime, use_container_width=True)

# --- TAB 2: Interprétation du Modèle ---
with tab_model:
    st.subheader(f"Performance du Modèle (R² = {r2_score:.3f})")
    st.write("Le coefficient R² indique la proportion de la variance de la note moyenne expliquée par les variables (budget, durée, genres) du modèle.")
    
    st.subheader("Impact des Caractéristiques (Coefficients de Régression)")
    st.markdown("Chaque coefficient représente l'augmentation (ou la diminution) de la note moyenne **prédite** si la caractéristique associée augmente de 1 (ou est présente pour un genre), **toutes choses égales par ailleurs**.")

    # Affichage des coefficients pour les variables continues
    st.markdown("#### Variables Continues (Budget & Durée)")
    cont_coeffs = coefficients[coefficients['Feature'].isin(['budget', 'runtime'])].copy()
    
    # Normalisation pour l'affichage (rendre le budget lisible)
    cont_coeffs.loc[cont_coeffs['Feature'] == 'budget', 'Coefficient'] *= 1e6
    cont_coeffs.loc[cont_coeffs['Feature'] == 'budget', 'Feature'] = 'Budget (par 1 million $)'

    st.dataframe(cont_coeffs.set_index('Feature'), use_container_width=True)
    st.info("⚠️ Le coefficient du budget est très petit car la variable elle-même est très grande. Nous avons multiplié la valeur par 1 million pour une meilleure interprétation : une augmentation de **1 million $** de budget change la note de cette valeur.")


    # Affichage des coefficients pour les genres
    st.markdown("#### Impact des Genres (Dummy Variables)")
    genre_coeffs = coefficients[coefficients['Feature'].isin(available_genres)].sort_values(by='Coefficient', ascending=False)

    # Graphique des coefficients des genres
    fig_genres = px.bar(genre_coeffs, 
                        x='Coefficient', 
                        y='Feature', 
                        orientation='h',
                        title='Impact relatif de chaque Genre sur la Note Prédite',
                        labels={'Feature': 'Genre', 'Coefficient': 'Impact sur la Note'})
    
    # Colore en vert les genres à impact positif et en rouge les genres à impact négatif
    fig_genres.update_traces(marker_color=['#FF5733' if c < 0 else '#33FF57' for c in genre_coeffs['Coefficient']])
    
    st.plotly_chart(fig_genres, use_container_width=True)
    
    st.markdown("""
    **Interprétation des Genres (Exemple) :**
    * Si un genre a un coefficient de **+0.5**, sa seule présence ajoute 0.5 point à la note de base (intercept du modèle), par rapport à un film qui n'aurait aucun des genres encodés.
    * Si un genre a un coefficient de **-0.3**, sa présence diminue la note de 0.3 point.
    """)

# --- 3. Conclusion (Optionnel mais souvent utile) ---
st.markdown("---")
st.caption("Données issues de TMDb et IMDb.")